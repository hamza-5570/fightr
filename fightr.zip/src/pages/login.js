import Login from "@/components/login";
import React from "react";

export default function LoginPage() {
  return (
    <>
      <Login />
    </>
  );
}
