import Registeration from "@/components/registeration";

export default function RegistrationPage() {
  return (
    <>
      <Registeration />
    </>
  );
}
